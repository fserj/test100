angular.module("News", []);
