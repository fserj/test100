//Main module pulls everything together
angular.module("GeekerNews", ["Login", "News"]);
