**uib-collapse** provides a simple way to hide and show an element with a css transition

### uib-collapse settings

* `uib-collapse`
  <i class="glyphicon glyphicon-eye-open"></i>
  _(Default: `false`)_ -
  Whether the element should be collapsed or not.
