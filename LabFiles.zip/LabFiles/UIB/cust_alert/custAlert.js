angular.module('uib.cust.alert', ['ui.bootstrap']);
//angular.module('uib.cust.alert', []);
