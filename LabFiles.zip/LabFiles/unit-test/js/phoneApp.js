var phoneApp = angular.module('phoneApp',[]);

phoneApp.controller('PhoneController', function($scope, phonesFactory) {
      
	 $scope.phones = phonesFactory.get();
	
	 $scope.$on("newPhone", function(event) {
	  $scope.phones = phonesFactory.get();
	 });

	
	 $scope.createPhone = function(){
		  phonesFactory.put($scope.phone);
		  $scope.phone = "";
	 }
});
 
phoneApp.directive('customColor', function() {
  return {
    restrict: 'A',
    link: function (scope, elem, attrs) {
      elem.css({"background-color": attrs.customColor});
    }
  }
});
 
phoneApp.filter('truncate', function(){
	return function(input, length) {
		return (input.length > length ? input.substring(0, length): input);
	};
}); 
 
phoneApp.factory('phonesFactory', function($rootScope){
   return {
      put: function(phone){
         localStorage.setItem('phone' + (Object.keys(localStorage).length + 1), phone);
			$rootScope.$broadcast("newPhone");
      },
      
      get: function(){
	      var phones = [];
         var keys = Object.keys(localStorage);
			for (var i = 0; i < keys.length; i++) {
			   phones.push(localStorage.getItem(keys[i]));
		   }
                    
         return phones;
      }
   }
});  